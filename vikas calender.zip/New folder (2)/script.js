document.addEventListener('DOMContentLoaded', function () {
    const calendarContainer = document.getElementById('calendar-container');
    const popup = document.getElementById('popup');
    const popupDate = document.getElementById('popup-date');
    const popupDetails = document.getElementById('popup-details');
    const saveBtn = document.getElementById('save-btn');
    const closeBtn = document.querySelector('.close-btn');
    const detailsStorage = {};

    function createCalendar() {
        const months = [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ];
        const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

        months.forEach((month, index) => {
            const monthContainer = document.createElement('div');
            monthContainer.className = 'month';
            
            const monthHeader = document.createElement('h3');
            monthHeader.textContent = month;
            monthContainer.appendChild(monthHeader);

            const daysContainer = document.createElement('div');
            daysContainer.className = 'days';
            
            daysOfWeek.forEach(day => {
                const dayElement = document.createElement('div');
                dayElement.textContent = day;
                daysContainer.appendChild(dayElement);
            });

            let startDay = new Date(2024, index, 1).getDay();
            for (let i = 0; i < startDay; i++) {
                const emptyCell = document.createElement('div');
                daysContainer.appendChild(emptyCell);
            }

            for (let day = 1; day <= daysInMonth[index]; day++) {
                const dayElement = document.createElement('div');
                dayElement.className = 'day';
                dayElement.textContent = day;
                dayElement.dataset.date = `${index + 1}/${day}/2024`;

                // Load stored details and update color
                const storedDetails = localStorage.getItem(dayElement.dataset.date);
                if (storedDetails) {
                    dayElement.classList.add('selected');
                }

                dayElement.addEventListener('click', function () {
                    showPopup(this.dataset.date);
                });

                daysContainer.appendChild(dayElement);
            }
            
            monthContainer.appendChild(daysContainer);
            calendarContainer.appendChild(monthContainer);
        });
    }

    function showPopup(date) {
        popupDate.textContent = date;
        popupDetails.value = localStorage.getItem(date) || '';
        popup.style.display = 'block';
    }

    function saveDetails() {
        const date = popupDate.textContent;
        const details = popupDetails.value;
        if (date && details !== null) {
            localStorage.setItem(date, details);
            document.querySelectorAll('.day').forEach(dayElement => {
                if (dayElement.dataset.date === date) {
                    dayElement.classList.add('selected');
                } else {
                    dayElement.classList.remove('selected');
                }
            });
            popup.style.display = 'none'; // Hide the popup after saving
        }
    }

    function closePopup() {
        popup.style.display = 'none';
    }

    saveBtn.addEventListener('click', saveDetails);
    closeBtn.addEventListener('click', closePopup);

    createCalendar();
});
